package CommonActivity;

public class OpenBrowserActivity {

}
